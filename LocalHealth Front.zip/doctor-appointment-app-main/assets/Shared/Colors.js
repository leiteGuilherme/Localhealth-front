export default{
    white:'#fff',
    PRIMARY:'#0165fc',
    SECONDARY:'#dbeafe',
    LIGHT_GRAY:'#e6e8eb',
    GRAY:'#a6a4a4'
}